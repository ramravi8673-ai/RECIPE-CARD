document.addEventListener("DOMContentLoaded", () => {

  /* ---------------------------------------------
     Collapsible panels (ingredients / steps)
  --------------------------------------------- */
  function setupToggle(toggleId, bodyId, showLabel, hideLabel, startOpen){
    const toggle = document.getElementById(toggleId);
    const body = document.getElementById(bodyId);
    const label = toggle.querySelector("span");

    function setState(open){
      toggle.setAttribute("aria-expanded", String(open));
      body.classList.toggle("open", open);
      label.textContent = open ? hideLabel : showLabel;
    }

    setState(startOpen);

    toggle.addEventListener("click", () => {
      const isOpen = toggle.getAttribute("aria-expanded") === "true";
      setState(!isOpen);
    });
  }

  setupToggle("ingredients-toggle", "ingredients-body", "Show Ingredients", "Hide Ingredients", false);
  setupToggle("steps-toggle", "steps-body", "Show Steps", "Hide Steps", true);

  /* ---------------------------------------------
     Start Cooking / Next Step sequencing
  --------------------------------------------- */
  const steps = Array.from(document.querySelectorAll(".step"));
  const startBtn = document.getElementById("start-cooking");
  const nextBtn = document.getElementById("next-step");
  const drizzleFill = document.getElementById("drizzle-fill");
  const drizzleLabel = document.getElementById("drizzle-label");
  const timerEl = document.getElementById("timer");
  const timerDisplay = document.getElementById("timer-display");

  const DRIZZLE_LENGTH = 640; // matches stroke-dasharray in CSS
  let currentIndex = -1;
  let countdownId = null;

  function updateDrizzle(){
    const progress = currentIndex < 0 ? 0 : (currentIndex + 1) / steps.length;
    const offset = DRIZZLE_LENGTH - DRIZZLE_LENGTH * progress;
    drizzleFill.style.strokeDashoffset = String(offset);

    if (currentIndex < 0){
      drizzleLabel.textContent = "Not started";
    } else if (currentIndex >= steps.length - 1){
      drizzleLabel.textContent = "Done — plate it up";
    } else {
      drizzleLabel.textContent = `Step ${currentIndex + 1} of ${steps.length}`;
    }
  }

  function activateStep(index){
    steps.forEach((step, i) => {
      step.classList.remove("active", "done");
      if (i < index) step.classList.add("done");
      if (i === index) step.classList.add("active");
    });
    if (steps[index]) {
      steps[index].scrollIntoView({ behavior: "smooth", block: "center" });
    }
    updateDrizzle();
  }

  function startCookingTimer(totalSeconds){
    timerEl.hidden = false;
    let remaining = totalSeconds;

    function render(){
      const m = Math.floor(remaining / 60).toString().padStart(2, "0");
      const s = Math.floor(remaining % 60).toString().padStart(2, "0");
      timerDisplay.textContent = `${m}:${s}`;
    }

    render();
    if (countdownId) clearInterval(countdownId);
    countdownId = setInterval(() => {
      remaining -= 1;
      if (remaining <= 0){
        remaining = 0;
        render();
        clearInterval(countdownId);
        timerDisplay.textContent = "Ready!";
        return;
      }
      render();
    }, 1000);
  }

  startBtn.addEventListener("click", () => {
    currentIndex = 0;
    activateStep(currentIndex);
    startBtn.disabled = true;
    nextBtn.disabled = false;

    const prep = parseInt(document.getElementById("prep-value").textContent, 10);
    const bake = parseInt(document.getElementById("bake-value").textContent, 10);
    startCookingTimer((prep + bake) * 60);
  });

  nextBtn.addEventListener("click", () => {
    if (currentIndex < steps.length - 1){
      currentIndex += 1;
      activateStep(currentIndex);
    }
    if (currentIndex >= steps.length - 1){
      nextBtn.disabled = true;
      nextBtn.textContent = "All Steps Done";
    }
  });

  updateDrizzle();

  /* ---------------------------------------------
     Print
  --------------------------------------------- */
  document.getElementById("print-btn").addEventListener("click", () => {
    window.print();
  });
});
